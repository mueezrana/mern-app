"use strict";

exports.polyfill = Component => Component;
//# sourceMappingURL=react-lifecycles-compat.js.map