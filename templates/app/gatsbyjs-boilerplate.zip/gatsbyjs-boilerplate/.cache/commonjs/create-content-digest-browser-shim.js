"use strict";

exports.createContentDigest = () => ``;
//# sourceMappingURL=create-content-digest-browser-shim.js.map