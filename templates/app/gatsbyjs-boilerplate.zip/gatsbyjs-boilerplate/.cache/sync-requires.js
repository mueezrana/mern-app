
// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---cache-dev-404-page-js": preferDefault(require("/Users/vijaypratapsingh/Desktop/Projects/create-mern-app/templates/app/gatsbyjs-app/.cache/dev-404-page.js")),
  "component---src-pages-404-js": preferDefault(require("/Users/vijaypratapsingh/Desktop/Projects/create-mern-app/templates/app/gatsbyjs-app/src/pages/404.js")),
  "component---src-pages-index-js": preferDefault(require("/Users/vijaypratapsingh/Desktop/Projects/create-mern-app/templates/app/gatsbyjs-app/src/pages/index.js")),
  "component---src-pages-login-js": preferDefault(require("/Users/vijaypratapsingh/Desktop/Projects/create-mern-app/templates/app/gatsbyjs-app/src/pages/login.js")),
  "component---src-pages-signup-js": preferDefault(require("/Users/vijaypratapsingh/Desktop/Projects/create-mern-app/templates/app/gatsbyjs-app/src/pages/signup.js"))
}

