const App = require('./src/App');

exports.onRenderBody = ({ setHtmlAttributes }) => {
    setHtmlAttributes({ lang: `en` });
};

exports.wrapPageElement = ({ element, props }) => {
    return <App {...props}>{element}</App>;
};
